<?php
echo password_hash('admin123', PASSWORD_DEFAULT);
?>