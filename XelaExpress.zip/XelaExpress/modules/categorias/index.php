<?php
// Módulo de categorías - próximamente
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Categorías - XelaExpress</title>
</head>
<body>
    <h2>Módulo de categorías (en desarrollo)</h2>
    <a href="../../dashboard.php">Volver al dashboard</a>
</body>
</html> 