<?php
// Módulo de proveedores - próximamente
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Proveedores - XelaExpress</title>
</head>
<body>
    <h2>Módulo de proveedores (en desarrollo)</h2>
    <a href="../../dashboard.php">Volver al dashboard</a>
</body>
</html> 