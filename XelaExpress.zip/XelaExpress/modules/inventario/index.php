<?php
// Módulo de inventario - próximamente
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario - XelaExpress</title>
</head>
<body>
    <h2>Módulo de inventario (en desarrollo)</h2>
    <a href="../../dashboard.php">Volver al dashboard</a>
</body>
</html> 