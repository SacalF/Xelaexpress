<?php
// Módulo de ventas - próximamente
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ventas - XelaExpress</title>
</head>
<body>
    <h2>Módulo de ventas (en desarrollo)</h2>
    <a href="../../dashboard.php">Volver al dashboard</a>
</body>
</html> 