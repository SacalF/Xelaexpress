<?php
// Módulo de clientes - próximamente
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Clientes - XelaExpress</title>
</head>
<body>
    <h2>Módulo de clientes (en desarrollo)</h2>
    <a href="../../dashboard.php">Volver al dashboard</a>
</body>
</html> 